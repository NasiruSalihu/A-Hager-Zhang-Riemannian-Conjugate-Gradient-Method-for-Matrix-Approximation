%function [Xsol, Ssol,T] = Orthogonal_procruste_problem
    
    p=5;%5
    n = 1000; %1000;
    l=n;
    B=ones(1000,5)/sqrt(1000); %ones(1000,5)
    A=eye(n);
    %A=randn(1000);%randn(1000)
    gGr = stiefelfactory(n, p);

    
    AB=A'*B;
    AA=A'*A;
    %AAX=AA*X;
    problem.M = gGr;
    problem.cost = @(X) norm(A*X-B, 'fro')^2;%-norm(B,"fro")^2;
    problem.egrad = @(X) 2*AA*X-2*AB;

    fprintf('Try it again without the linesearch helper.\n');
    BETAS = {'F-R','P-R', 'H-S', 'L-S', 'D-Y', 'H-Z', 'R-RMIL+', 'R-NHS', 'H-FP', 'H-FP2', 'DLRMIL', 'DLDY', 'DLLS+', 'DLCD' };
    %BETAS = {'F-R','P-R', 'H-S', 'L-S',  'R-NHS', 'H-FP', 'H-FP2', 'HRCG', 'HRCG2'};
    table1 = 'RCGmulti.xlsx';

    MaxTrial =100;
    for i=1:MaxTrial
         x = problem.M.rand();
         for k = 1:length(BETAS)
            options.beta_type = BETAS{k}; % set to 0 to silence the solver, 2 for normal output.
            [Xsol, costXsol, info,options, finalout] = conjugategradientDL(problem, x, options, k); %#ok<ASGLU>
            %T = {BETAS{k}  num2str(finalout.iter) num2str(finalout.newcost) num2str(finalout.newgradnorm) num2str(finalout.time) };
            T = {BETAS{k}  num2str(finalout.iter)  num2str(finalout.time) };
            sheet=3; % can be made adaptive;
            XRange=xlRange(3*k, i);
            xlswrite(table1,T,sheet,XRange);
         end

    end

    [Vsol, Dsol] = eig(Xsol'*(A*Xsol));
    Ssol = diag(Dsol);
    
    T=info;
    