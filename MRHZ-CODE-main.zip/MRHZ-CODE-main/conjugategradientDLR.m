function [x, cost, info, options, finalout] = conjugategradientDLR(problem, x, options,k)

M = problem.M;

% Verify that the problem description is sufficient for the solver.
if ~canGetCost(problem)
    warning('manopt:getCost', ...
        'No cost provided. The algorithm will likely abort.');
end
if ~canGetGradient(problem) && ~canGetApproxGradient(problem)
    warning('manopt:getGradient:approx', ...
           ['No gradient provided. Using an FD approximation instead (slow).\n' ...
            'It may be necessary to increase options.tolgradnorm.\n' ...
            'To disable this warning: warning(''off'', ''manopt:getGradient:approx'')']);
    problem.approxgrad = approxgradientFD(problem);
end

% Set local defaults here
localdefaults.minstepsize = 1e-10;
localdefaults.maxiter = 2000;
localdefaults.tolgradnorm = 1e-6;
localdefaults.storedepth = 20;

localdefaults.orth_value = Inf; % by BM as suggested in Nocedal and Wright

 if ~canGetLinesearch(problem)
%       localdefaults.linesearch = @linesearch_Sadaptive;
      localdefaults.linesearch = @linesearch_SSadaptive;
     
else
%       localdefaults.linesearch = @linesearch_hint;
    localdefaults.linesearch = @linesearch_SSadaptive;
end

% Merge global and local defaults, then merge w/ user options, if any.
localdefaults = mergeOptions(getGlobalDefaults(), localdefaults);
if ~exist('options', 'var') || isempty(options)
    options = struct();
end
options = mergeOptions(localdefaults, options);

timetic = tic();

% Create a store database and generate a key for the current x
storedb = StoreDB(options.storedepth);
key = storedb.getNewKey();

% Compute cost-related quantities for x
[cost, grad] = getCostGrad(problem, x, storedb, key);
gradnorm = M.norm(x, grad);
Pgrad = getPrecon(problem, x, grad, storedb, key);
gradPgrad = M.inner(x, grad, Pgrad);

% Iteration counter (at any point, iter is the number of fully executed
% iterations so far)
iter = 0;

tic;
% Save stats in a struct array info and preallocate.
stats = savestats();
info(1) = stats;
info(min(10000, options.maxiter+1)).iter = [];

if options.verbosity >= 2
    fprintf(' iter\t               cost val\t    grad. norm\n ');
end

% Compute a first descent direction (not normalized)
desc_dir = M.lincomb(x, -1, Pgrad);

% iternum = []; valnum = []; gradnum = []; timNum = [];
% Start iterating until stopping criterion triggers
while true
%     timetic = tic();
    % Display iteration information
    if options.verbosity >= 2
        fprintf('%5d\t%+.16e\t%.8e\n', iter, cost, gradnorm);
    end
    
    % Start timing this iteration

    % Run standard stopping criterion checks
    [stop, reason] = stoppingcriterion(problem, x, options, info, iter+1);
    
    % Run specific stopping criterion check
    if ~stop && abs(stats.stepsize) < options.minstepsize
        stop = true;
        reason = sprintf(['Last stepsize smaller than minimum '  ...
                          'allowed; options.minstepsize = %g.'], ...
                          options.minstepsize);
    end
    
    if stop
        if options.verbosity >= 1
            fprintf([reason '\n']);
        end
        break;
    end
    
    % The line search algorithms require the directional derivative of the
    % cost at the current point x along the search direction.
    df0 = M.inner(x, grad, desc_dir);
        
    
    if df0 >= 0
        
        % Or we switch to the negative gradient direction.
        if options.verbosity >= 3
            fprintf(['Conjugate gradient info: got an ascent direction '...
                     '(df0 = %2e), reset to the (preconditioned) '...
                     'steepest descent direction.\n'], df0);
        end
        % Reset to negative gradient: this discards the CG memory.
        desc_dir = M.lincomb(x, -1, Pgrad);
        df0 = -gradPgrad;
        
    end
    
    % Execute line search
    [stepsize, newx, newkey, lsstats] = options.linesearch( ...
                   problem, x, desc_dir, cost, df0, options, storedb, key);
               
    
    % Compute the new cost-related quantities for newx
    [newcost, newgrad] = getCostGrad(problem, newx, storedb, newkey);
    newgradnorm = M.norm(newx, newgrad);
    Pnewgrad = getPrecon(problem, newx, newgrad, storedb, newkey);
    newgradPnewgrad = M.inner(newx, newgrad, Pnewgrad);
    
    
    % Apply the CG scheme to compute the next search direction.

    if strcmpi(options.beta_type, 'steep') || ...
       strcmpi(options.beta_type, 'S-D')              % Gradient Descent
        
        beta = 0;
        desc_dir = M.lincomb(newx, -1, Pnewgrad);
        
    else
        
        oldgrad = M.transp(x, newx, grad);
        orth_grads = M.inner(newx, oldgrad, Pnewgrad) / newgradPnewgrad;
        
        % Powell's restart strategy (see page 12 of Hager and Zhang's
        % survey on conjugate gradient methods, for example)
        if abs(orth_grads) >= options.orth_value
            beta = 0;
            desc_dir = M.lincomb(x, -1, Pnewgrad);
            
        else % Compute the CG modification
            
            desc_dir = M.transp(x, newx, desc_dir);
            
            switch upper(options.beta_type)
            
               case 'RFR'  % Fletcher-Reeves 1
                    beta = newgradPnewgrad / gradPgrad;
                    theta = 1;
                    desc_dir = M.lincomb(newx, - theta, Pnewgrad, beta, desc_dir);

               case 'RHZ' % Hager-Zhang+4
                    diff = M.lincomb(newx, 1, newgrad, -1, oldgrad);
                    Poldgrad = M.transp(x, newx, Pgrad);
                    Pdiff = M.lincomb(newx, 1, Pnewgrad, -1, Poldgrad);
                    deno = M.inner(newx, diff, desc_dir);
                    numo = M.inner(newx, diff, Pnewgrad);
                    numo = numo - 2*M.inner(newx, diff, Pdiff)*M.inner(newx, desc_dir, newgrad) / deno;
                    beta = numo / deno;

                    % Robustness (see Hager-Zhang paper mentioned above)
                    desc_dir_norm = M.norm(newx, desc_dir);
                    eta_HZ = -1 / ( desc_dir_norm * min(0.01, gradnorm) );
                    beta = max(beta, eta_HZ);

                    theta = 1;
                    desc_dir = M.lincomb(newx, - theta, Pnewgrad, beta, desc_dir);
                                
                             
                             
                
                case 'SMRMIL'
                    desc_dir_norm = M.norm(newx, desc_dir);
                    diff = M.lincomb(newx, 1, newgrad, -1, oldgrad);
                    MR = abs(M.inner(newx, diff, desc_dir));
                    beta1 = MR / desc_dir_norm^2;
                    beta2 = newgradPnewgrad / desc_dir_norm^2;
                    beta = min(beta1, beta2); 


                 case 'H-HD' % Hybrid HS-DY 
                    diff = M.lincomb(newx, 1, newgrad, -1, oldgrad);
                    ip_diff = M.inner(newx, Pnewgrad, diff);
                    betaHS = ip_diff / M.inner(newx, diff, desc_dir);
                    betaHS = max(0, betaHS);
                    betaDy = newgradPnewgrad  / M.inner(newx, diff, desc_dir);
                    betaDy = max(0, betaDy);
                    beta = max(0, min(betaHS, betaDy));
                    theta = 1;
                    desc_dir = M.lincomb(newx, - theta, Pnewgrad, beta, desc_dir);
  

               case 'H-FP' % Hybrid FR-PRP
                    diff = M.lincomb(newx, 1, newgrad, -1, oldgrad);
                    ip_diff = M.inner(newx, Pnewgrad, diff);
                    betaFr = newgradPnewgrad / gradPgrad;
                    betaPrp = ip_diff / gradPgrad;
                    betaPrp = max(0, betaPrp);
                    beta = max(0, min(betaFr, betaPrp));
                    theta = 1;
                    desc_dir = M.lincomb(newx, - theta, Pnewgrad, beta, desc_dir);
    
                case 'H-FP2' %Hybrid FR-PRP2
                    diff = M.lincomb(newx, 1, newgrad, -1, oldgrad);
                    ip_diff = M.inner(newx, Pnewgrad, diff); %manifold.inner_product(newx, Pnewgrad, diff)
                    betafr = newgradPnewgrad / gradPgrad;
                    betapr = max(0, ip_diff / gradPgrad);
                    
                    if  0 <=min(betafr,betapr) 
                        beta=min(betafr,betapr); 
                    else
                        beta=betafr; 
                    %return betahyb4
                    end
                   desc_dir = M.lincomb(newx, - 1, Pnewgrad, beta, desc_dir);

                
               
                 case 'MRHZ1'
                    y  = M.lincomb(newx,1,Pnewgrad,-1,M.transp(x,newx,Pgrad));   % y_k = g_{k+1} - transported g_k
                    Td = M.transp(x,newx,desc_dir);                               % T(delta_k)
                    
                    Gamma = M.inner(newx,Pnewgrad,Td) - M.inner(x,Pgrad,desc_dir);
                    gamma1 = M.inner(newx,Pnewgrad,y)/(Gamma + 1e-10);
                    gamma2 = (M.norm(newx,y)^2 * M.inner(newx,Pnewgrad,Td))/(Gamma^2 + 1e-10);
                    
                    % RHZ beta
                    mu_val = 2;
                    mu_max=100;
                    mu_min=1;

                    beta_RHZ = gamma1 - mu_val * gamma2;
                    
                    % MRHZ1 adaptive mu
                    rho = M.norm(newx,Pnewgrad) - 2;
                    rho_MR = (Gamma >= M.norm(newx,y)*M.norm(newx,Pnewgrad)*M.norm(x,desc_dir)) * rho ...
                             + (Gamma <  M.norm(newx,y)*M.norm(newx,Pnewgrad)*M.norm(x,desc_dir)) * mu_min;
                    mu_MR = min(mu_max, max(mu_min, rho_MR));
                    
                    % MRHZ1 beta and update
                    beta_MRHZ1 = beta_RHZ - min(beta_RHZ, -mu_MR * gamma2);
                    desc_dir = M.lincomb(newx,-1,Pnewgrad,beta_MRHZ1,desc_dir);
                                        
               case 'MRHZ2'
                                       %% --- MRHZ2 update ---
                    gk_norm2 = M.norm(x,Pgrad)^2;      % ||g^k||^2
                    gk_norm4 = gk_norm2^2;
                    
                    diff = M.lincomb(newx, 1, newgrad, -1, oldgrad); % y_k = g_{k+1} - g_k
                    y_norm = M.norm(x, diff);
                    
                    Td      = M.transp(x,newx,desc_dir);               
                    
                    % gamma^3 and gamma^4
                    gamma3 = M.inner(newx,Pnewgrad,diff)/(gk_norm2);
                    gamma4 = (y_norm^2 * M.inner(newx,Pnewgrad,Td)) / (gk_norm4);
                    
                    % rho^{RHZ2} safeguard
                    rho_MR2 = (gk_norm4 - M.norm(newx,Pnewgrad)*y_norm*gk_norm2*M.norm(x,desc_dir)) ...
                              / (y_norm^2 * M.norm(newx,Pnewgrad) * M.norm(x,desc_dir)^2);
                    
                    
                    mu_min=1;
                    mu_max=100;
                    % adaptive mu
                    mu_MR2 = min(mu_max, max(mu_min, rho_MR2));
                    
                    % MRHZ2 beta
                    beta_MRHZ2 = gamma3 - min(gamma3, mu_MR2*gamma4);
                    
                    % update search direction
                    desc_dir = M.lincomb(newx,-1,Pnewgrad,beta_MRHZ2,desc_dir);
               
                  
                otherwise
                    error(['Unknown options.beta_type. ' ...
                           'Should be steep, S-D, F-R, P-R, H-S, R-M, D-Y or H-Z.']);
            end

            
        end
        
    end    
    % Transfer iterate info.
    storedb.removefirstifdifferent(key, newkey);
    x = newx;
    key = newkey;
    cost = newcost;
    grad = newgrad;
    Pgrad = Pnewgrad;
    gradnorm = newgradnorm;
    gradPgrad = newgradPnewgrad;
    
    % iter is the number of iterations we have accomplished.
    iter = iter + 1;
    

    % Make sure we don't use too much memory for the store database.
    storedb.purge();
    
    % Log statistics for freshly executed iteration.
    stats = savestats();
    info(iter+1) = stats;

end

finalout.iter = iter;
finalout.newcost = newcost;
finalout.newgradnorm = newgradnorm;
finalout.time = toc;

toc; 

info = info(1:iter+1);

if options.verbosity >= 1
    fprintf('Total time is %f [s] (excludes statsfun)\n', info(end).time);
end


% Routine in charge of collecting the current iteration stats
function stats = savestats()
    stats.iter = iter;
    stats.cost = cost;
    stats.gradnorm = gradnorm;
    if iter == 0
        stats.stepsize = nan;
        stats.time = toc(timetic);
        stats.linesearch = [];
        stats.beta = 0;
    else
        stats.stepsize = stepsize;
        stats.time = info(iter).time + toc(timetic);
        stats.linesearch = lsstats;
        stats.beta = beta;
    end
    stats = applyStatsfun(problem, x, storedb, key, options, stats);
end

end

