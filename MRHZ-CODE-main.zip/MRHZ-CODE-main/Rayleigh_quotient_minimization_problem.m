%function [Xsol, Ssol,T] = Rayleigh_quotient_minimization_problem
    
    A=diag(1:1000);
    n = size(A, 1);
    %gGr = spherefactory(n);
    gGr = stiefelfactory(n,1);
    
    problem.M = gGr;
    problem.cost  = @(X)    (X'*A*X);
    problem.egrad = @(X)    2*(A*X);

    fprintf('Try it again without the linesearch helper.\n');
    BETAS = {'F-R','P-R', 'H-S', 'L-S', 'D-Y', 'H-Z', 'R-RMIL+', 'R-NHS', 'H-FP', 'H-FP2', 'DLRMIL', 'DLDY', 'DLLS+', 'DLCD' };
    
    table1 = 'RCGmulti.xlsx';

    MaxTrial =100;
    for i=1:MaxTrial
         x = problem.M.rand();
         for k = 1:length(BETAS)
            options.beta_type = BETAS{k}; % set to 0 to silence the solver, 2 for normal output.
            [Xsol, costXsol, info,options, finalout] = conjugategradientDL(problem, x, options, k); %#ok<ASGLU>
            %T = {BETAS{k}  num2str(finalout.iter) num2str(finalout.newcost) num2str(finalout.newgradnorm) num2str(finalout.time) };
            T = {BETAS{k}  num2str(finalout.iter)  num2str(finalout.time) };
            sheet=2; % can be made adaptive;
            XRange=xlRange(3*k, i);
            xlswrite(table1,T,sheet,XRange);
         end

    end

    [Vsol, Dsol] = eig(Xsol'*(A*Xsol));
    Ssol = diag(Dsol);
    
    T=info;
    


